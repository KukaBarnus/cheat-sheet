# Feladatsor

1. Írassuk ki az aktuális könyvtár nevét:
```bash

```

2. Írassuk ki az aktuális könyvtár tartalomjegyzékét teljes részletességgel:
```bash
 
```

3. Hozzunk létre egy temp és egy munka könyvtárat az aktuális könyvtáron belül:
```bash
 
 
```

4. Készítsünk egy szöveges állományt forras néven a saját könyvtárunkban bármilyen
tartalommal. A Ctrl+D billentyűkombináció hatására befejeződik a beírás, és lementődik a
szöveg.
```bash
 
 
 
```

5. Nézzük meg az állomány tartalmát:
```bash
 
```
6. Másoljuk be az állományt a temp és a munka könyvtárakba forr_temp és forr_munka
néven.
```bash
 
 
```

7. Tegyük a forr_temp–et írásvédetté:
```bash
 
```

8. Készítsünk a munka könyvtárban hardlinket a forras állományra:
```bash
 
```

9. Készítsünk a temp könyvtárban szimbolikus hivatkozást a forras állományra:
```bash
 
```

10. Nézzük meg, hogy hány hardlink hivatkozás van a forras-ra:
```bash
 
```

11. Töröljük az egyik merev keresztkapcsolatot. Írassuk ki, hogy ezután hány hivatkozás van a
forras-ra.
```bash
 
```

12. Töröljük a konzolablak tartalmát.
```bash
 
```

13. Csomagoljuk be a munka, és a temp könyvtárakat valamint a forras állományt.
```bash
 
```

14. Ellenőrizzük le a csomag tartalmát:
```bash
 
```

15. Tömörítsük a csomagot:
```bash
 
```

16. Mozgassuk át a csomagot a munka könyvtárba, és csomagoljuk ott ki:
```bash
 
 
```

17. Lépjünk be a munka könyvtárba majd csomagoljuk ott ki a csomag.tar állományt.
```bash
 
 
```

18. Lépjünk ki a munka könyvtárból, majd töröljük a munka és a temp könyvtárakat.
```bash
  
  
  
```

19. Töröljük a forrás állományt.
```bash
 
```
